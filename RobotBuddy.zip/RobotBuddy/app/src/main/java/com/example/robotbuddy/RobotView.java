package com.example.robotbuddy;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

/** Draws the robot with plain shapes, so no image files are needed. */
public class RobotView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    boolean walking = true;
    long talkUntil = 0;

    public RobotView(Context c) { super(c); }

    private void rect(Canvas c, float l, float t, float r, float b, int color) {
        p.setColor(color);
        c.drawRoundRect(l, t, r, b, 10, 10, p);
    }

    private void dot(Canvas c, float x, float y, float radius, int color) {
        p.setColor(color);
        c.drawCircle(x, y, radius, p);
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        c.scale(getWidth() / 100f, getHeight() / 120f);
        float step = walking ? (float) Math.sin(now / 100.0) * 5 : 0;
        rect(c, 48, 8, 52, 22, 0xFF546E7A);
        dot(c, 50, 8, 6, 0xFFFF7043);
        rect(c, 30, 98, 44, 112 + step, 0xFF546E7A);
        rect(c, 56, 98, 70, 112 - step, 0xFF546E7A);
        rect(c, 10, 70 + step, 24, 92 + step, 0xFF78909C);
        rect(c, 76, 70 - step, 90, 92 - step, 0xFF78909C);
        rect(c, 26, 66, 74, 102, 0xFF26A69A);
        rect(c, 18, 20, 82, 68, 0xFF80CBC4);
        if (now % 3000 < 150) {            // blink
            rect(c, 30, 39, 44, 42, 0xFF102027);
            rect(c, 56, 39, 70, 42, 0xFF102027);
        } else {
            dot(c, 37, 40, 7, 0xFF102027);
            dot(c, 63, 40, 7, 0xFF102027);
            dot(c, 39, 38, 2, 0xFFFFFFFF);
            dot(c, 65, 38, 2, 0xFFFFFFFF);
        }
        float mouth = now < talkUntil && (now / 150) % 2 == 0 ? 9 : 3;
        rect(c, 40, 54, 60, 54 + mouth, 0xFF102027);
        postInvalidateDelayed(50);
    }
}
