package com.example.robotbuddy;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.Toast;
import java.util.Locale;
import java.util.Random;

public class RobotService extends Service {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private RobotView robot;
    private TextToSpeech tts;
    private boolean ttsReady, held;
    private int targetX, targetY, size;
    private long restUntil, nextChat;

    private final String[] tapLines = {
        "আরে! সুড়সুড়ি লাগছে!", "কী খবর বন্ধু?", "আমাকে ডাকলে?",
        "সারাদিন শুধু ফোন? একটু পানি খাও!", "আমি কিন্তু সব দুষ্টুমি পারি!"};
    private final String[] idleLines = {
        "আমি একটু ঘুরে আসি!", "টুকি! আমাকে দেখছো?", "আমার খুব বোর লাগছে।", "একটু খেলবে আমার সাথে?"};

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("robot", "Robot", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, RobotService.class).setAction("stop"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, "robot")
                .setSmallIcon(android.R.drawable.star_on)
                .setContentTitle("রোবট ঘুরছে")
                .setContentText("বন্ধ করতে এখানে চাপুন")
                .setContentIntent(stop).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);

        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return; }

        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) return;
            ttsReady = tts.setLanguage(new Locale("bn", "BD")) >= TextToSpeech.LANG_AVAILABLE;
            tts.setPitch(1.5f);
        });

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        float d = getResources().getDisplayMetrics().density;
        size = (int) (80 * d);
        lp = new WindowManager.LayoutParams(size, size * 6 / 5,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.x = 100; lp.y = 300;
        targetX = lp.x; targetY = lp.y;
        robot = new RobotView(this);
        robot.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean dragged;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    held = true; dragged = false;
                    downX = e.getRawX(); downY = e.getRawY(); startX = lp.x; startY = lp.y;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (Math.hypot(dx, dy) > 10 * d) dragged = true;
                    if (dragged) {
                        lp.x = startX + (int) dx; lp.y = startY + (int) dy;
                        wm.updateViewLayout(robot, lp);
                    }
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    held = false; targetX = lp.x; targetY = lp.y;
                    restUntil = SystemClock.uptimeMillis() + 2000;
                    if (e.getAction() == MotionEvent.ACTION_UP)
                        say(dragged ? "উফ! আমাকে টানাটানি করছো কেন?" : pick(tapLines));
                }
                return true;
            }
        });
        wm.addView(robot, lp);
        nextChat = SystemClock.uptimeMillis() + 20000;
        handler.post(tick);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long now = SystemClock.uptimeMillis();
            robot.walking = false;
            if (!held && now > restUntil) {
                int w = getResources().getDisplayMetrics().widthPixels;
                int h = getResources().getDisplayMetrics().heightPixels;
                int dx = targetX - lp.x, dy = targetY - lp.y;
                double dist = Math.hypot(dx, dy);
                if (dist < 8) {
                    targetX = random.nextInt(Math.max(1, w - size));
                    targetY = random.nextInt(Math.max(1, h - size * 2));
                    restUntil = now + 1500 + random.nextInt(4000);
                } else {
                    lp.x += (int) Math.round(dx / dist * 6);
                    lp.y += (int) Math.round(dy / dist * 6);
                    robot.walking = true;
                    wm.updateViewLayout(robot, lp);
                }
            }
            if (now > nextChat) {
                say(pick(idleLines));
                nextChat = now + 40000 + random.nextInt(40000);
            }
            handler.postDelayed(this, 30);
        }
    };

    private String pick(String[] a) { return a[random.nextInt(a.length)]; }

    private void say(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        robot.talkUntil = SystemClock.uptimeMillis() + 2500;
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "robot");
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "stop".equals(i.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (robot != null && robot.isAttachedToWindow()) wm.removeView(robot);
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
